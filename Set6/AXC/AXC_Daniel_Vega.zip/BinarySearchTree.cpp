// Daniel Vega

#include "BinarySearchTree.hpp"

// Explicit instantiation for int
template class BinarySearchTree<int>;
