// Console chess entry point
#include "game.h"

int main() {
    Game game;
    game.start();
    return 0;
}
