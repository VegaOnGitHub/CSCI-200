#ifndef EXIT_ROOM_H
#define EXIT_ROOM_H

#include "Room.h"

class ExitRoom {
public:
    ExitRoom();
    ~ExitRoom();
};

#endif//EXIT_ROOM_H