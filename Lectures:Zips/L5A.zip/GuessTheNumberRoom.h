#ifndef GUESS_THE_NUMBER_ROOM_H
#define GUESS_THE_NUMBER_ROOM_H

#include "Room.h"

class GuessTheNumberRoom {
public:
    GuessTheNumberRoom();
    ~GuessTheNumberRoom();
private:
    int _secretNumber;
};

#endif//GUESS_THE_NUMBER_ROOM_H