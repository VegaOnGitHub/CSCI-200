#ifndef QUADRILATERAL_H
#define QUADRILATERAL_H

#include "Polygon.h"

class Quadrilateral : public Polygon {
public:
    Quadrilateral();
    ~Quadrilateral() override = default;
};

#endif  // QUADRILATERAL_H
