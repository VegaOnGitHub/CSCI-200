#include "game.h"

int main() {
    chess::Game game;
    game.start();
    return 0;
}
